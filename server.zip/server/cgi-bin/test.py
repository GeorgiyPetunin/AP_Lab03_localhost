#!/usr/bin/env python3

print("Content-type: text/html")
print()
print("Hello World! привет мир!")
